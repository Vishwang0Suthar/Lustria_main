import React from 'react'


type Props = {}

const Testi = (props: Props) => {
  return (
    <>
    <div className="flex flex-col justify-center items-center">
        <h1 className='text-[#7fa15a] text-xl font-500 tracking-wider mb-3 pt-5'>Welcome to Lustria</h1>
        <h1 className='text-[40px] font-medium '>Testimonials</h1>
        </div> 
    </>
)
}

export default Testi